#include "RTE_Components.h"
#include  CMSIS_device_header
#include "cmsis_os2.h"
#include "Board_LED.h" 
//Port 2 Pins
#define DIR_Bit1   (*((volatile unsigned long *)0x23380804))
#define DIR_Bit2   (*((volatile unsigned long *)0x23380808))
#define DIR_Bit3   (*((volatile unsigned long *)0x2338080C))
#define DIR_Bit4   (*((volatile unsigned long *)0x23380810))
#define DIR_Bit5   (*((volatile unsigned long *)0x23380814))
#define DIR_Bit6   (*((volatile unsigned long *)0x23380818))
#define DIR_Bit7   (*((volatile unsigned long *)0x2338081C))

uint32_t vara,varb, number;
osThreadId_t w1, w2, t2, t3;

void delay(int ms){
    int i = 0;
    int j = 0;
    for(i = 0; i < ms; i++){
        for(j = 0; j < 1000; j++);
    }
}

static const osThreadAttr_t ThreadAttr_worker = {
    .name = "Worker",
    .attr_bits = osThreadJoinable,
    .priority = osPriorityHigh,
};

__NO_RETURN void thread1 (void *argument) {
		DIR_Bit4 = 1;
		int i,flag = 0;
	  if(number == 1){
			for(i = 2; i<=vara/2;++i){
				if(vara%i == 0){
						flag = 1;
						break;
				}
			}
			if (vara == 1){
				DIR_Bit1 = 1;
				delay(800);
			}
			else{
				if(flag ==0){
					DIR_Bit2 = 1;
					delay(800);
				}
				else{
					DIR_Bit3 = 1;
					delay(800);
				}
			}
		}
		if(number == 0){
			for(i = 2; i<=varb/2;++i){
				if(varb%i == 0){
						flag = 1;
						break;
				}
			}
			if (varb == 1){
				DIR_Bit5 = 1;
				delay(800);
			}
			else{
				if(flag ==0){
					DIR_Bit6 = 1;
					delay(800);
				}
				else{
					DIR_Bit7 = 1;
					delay(800);
				}
			}
		}
			DIR_Bit1 = 0; 
			DIR_Bit2 = 0; 
			DIR_Bit3 = 0;
			DIR_Bit4 = 0;
			DIR_Bit5 = 0;
			DIR_Bit6 = 0;
			DIR_Bit7 = 0;
		
			delay(800);	
		osThreadExit();
}

__NO_RETURN static void thread2 (void *argument) {
				uint32_t a=1,b=2,count=1; 
  for (;;) {
				// Arithmatic Sequence
				vara = a + count*b;
				count++;
				delay(80);
				number = 1;
				w1 = osThreadNew(thread1, &vara, &ThreadAttr_worker);
				osThreadJoin(w1);
				number = 3;
				osThreadYield();
	}
}
__NO_RETURN static void thread3 (void *argument) {//(void)argument;

				uint32_t count2 = 4;
  for (;;) {
				varb = varb+count2/2;
				count2 = count2+2;
				delay(80);
				number = 0;
				w2 = osThreadNew(thread1, &varb, &ThreadAttr_worker);
				osThreadJoin(w2);
				number = 3;
				osThreadYield();
	}
}

int main (void) {
  SystemCoreClockUpdate();
  // ...
	LED_Initialize();
  osKernelInitialize();                 // Initialize CMSIS-RTOS
	t2 = osThreadNew(thread2,NULL,NULL);
	t3 = osThreadNew(thread3,NULL,NULL);
  osKernelStart();                      // Start thread execution
  for (;;) {}
}
