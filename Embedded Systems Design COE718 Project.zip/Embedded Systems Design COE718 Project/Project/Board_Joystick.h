#ifndef __BOARD_JOYSTICK_H 
#define __BOARD_JOYSTICK_H 
 
#include <stdint.h> 
 
#define JOYSTICK_LEFT                   (1 << 0)  /// Defines the Left-button 
#define JOYSTICK_RIGHT                  (1 << 1)  /// Defines the Right-button 
#define JOYSTICK_CENTER                 (1 << 2)  /// Defines the Center-button 
#define JOYSTICK_UP                     (1 << 3)  /// Defines the Up-button 
#define JOYSTICK_DOWN                   (1 << 4)  /// Defines the Down-button 
 
/**
	\fn          int32_t Joystick_Initialize (void)   
	\brief       Initialize joystick   
	\returns    
	- \b  0: function succeeded    
	- \b -1: function failed 
*/ 
/**   
	\fn          int32_t Joystick_Uninitialize (void)   
	\brief       De-initialize joystick   
	\returns    
	- \b  0: function succeeded    
	- \b -1: function failed 
*/ 
/**   
	\fn          uint32_t Joystick_GetState (void)   
	\brief       Get joystick state   
	\returns     Joystick state 
*/ 
 
extern int32_t  Joystick_Initialize     (void); 
extern int32_t  Joystick_Uninitialize   (void); 
extern uint32_t Joystick_GetState       (void); 
 
#endif /* __BOARD_JOYSTICK_H */
