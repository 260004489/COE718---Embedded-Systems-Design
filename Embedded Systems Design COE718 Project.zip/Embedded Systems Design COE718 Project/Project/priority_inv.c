#define osObjectsPublic            
#include "osObjects.h"                  
#include "cmsis_os.h"                   
#include <stdio.h>
#include <math.h>
#include "Board_LED.h"                
#include "RTE_Components.h"            
#include <stdbool.h>
#include "Board_Joystick.h"
  
void taskA (void const *argument);
void taskB (void const *argument);
void taskC (void const *argument);
void transition (void const *argument);

osThreadDef(taskA, osPriorityHigh, 1, 0);
osThreadDef(taskB, osPriorityNormal, 1, 0);
osThreadDef(taskC, osPriorityLow, 1, 0);
osThreadDef(transition, osPriorityHigh,1,0);

osThreadId t_main,P1,P2,P3, trans;
osPriority priority; osThreadId id;

uint32_t count2 = 10;
uint32_t count3;
uint32_t variable = 0;                         
uint32_t joystick_position = 0;       


osSemaphoreDef (sem);
osSemaphoreId (sem);

osMutexId mut;
osMutexDef(mut);

void delay(){ 
	long k, count = 0;
	for(k = 0; k < 100000; k++){
					count++;
			}
}
	
int init_thread(void){
		if(joystick_position & JOYSTICK_RIGHT){
				printf("Priority Inversion solution by mutex\n");
		}
		if(joystick_position & JOYSTICK_LEFT){
				printf("Priority Inversion solution by resmble-semaphore\n");
		}
		if(joystick_position & JOYSTICK_DOWN){
				printf("Priority Inversion solution by semaphore\n");
		}
		P1 = osThreadCreate(osThread(taskA), NULL);
		P2 = osThreadCreate(osThread(taskB), NULL);
		P3 = osThreadCreate(osThread(taskC), NULL);
     
		return(0);	
}

void step(void){
		osThreadTerminate(P2);
		osThreadTerminate(P3);
		osThreadTerminate(P1);
	
		init_thread();
}

void taskA (void const *argument) {	
	uint32_t count_A = 0;
	uint32_t temp;
	osDelay(100);
	osStatus s;
		
	if (joystick_position & JOYSTICK_RIGHT) {            //P1_24    //Mutex
		for (;;){
			osMutexWait(mut,osWaitForever);
			if(s == osOK){
				LED_On(0);
				for(count2= 0;count2<1000;count2++){
					count_A += count2;
				}	
				osMutexRelease(mut);	
			}	
			joystick_position = Joystick_GetState();
			if (joystick_position & JOYSTICK_LEFT || joystick_position & JOYSTICK_DOWN ) {		
				trans = osThreadCreate(osThread(transition),NULL); 
			}		
		}
	}	
		
	if (joystick_position & JOYSTICK_DOWN) {         //P1_25    //Semaphore
		for (;;){
			temp = osSemaphoreWait(sem,50);
			if(temp == 0){
				osThreadSetPriority(P3,osPriorityRealtime);
			}	
			if(temp > 0){
				LED_On(0);
				for(count2= 0;count2<1000;count2++){
					count_A+= count2;
				}	
			osSemaphoreRelease(sem);		
			}	
			joystick_position = Joystick_GetState();
			if (joystick_position & JOYSTICK_LEFT || joystick_position & JOYSTICK_RIGHT ) {		
				trans = osThreadCreate(osThread(transition),NULL); 
			}	
		}	
	}			
		
	if (joystick_position & JOYSTICK_LEFT) {					//P1_26   // Resemble Semaphore
		while(1){
			if(variable ==1){
				osDelay(100);
				osThreadSetPriority(P3, osPriorityRealtime);
			}
			if(variable == 0){
				for(count2= 0;count2<1000;count2++){
					count_A+= count2;
				}
			}
			joystick_position = Joystick_GetState();
			if (joystick_position & JOYSTICK_DOWN || joystick_position & JOYSTICK_RIGHT ) {		
				trans = osThreadCreate(osThread(transition),NULL); 
			}
		}
	}
	for (;;){
		LED_On(0);
		osSignalSet(P3,0x01);	
		osSignalWait(0x02,osWaitForever);	
		for(count2= 0;count2<200;count2++){
			count_A+= count2;
		}
		joystick_position = Joystick_GetState();
		if(joystick_position & JOYSTICK_DOWN || joystick_position & JOYSTICK_RIGHT || joystick_position & JOYSTICK_LEFT){
			trans = osThreadCreate(osThread(transition),NULL); 	
		}
	}
}
void taskB (void const *argument){
	uint32_t r = 1;
	count3 = 2;
	osDelay(100);

	if (joystick_position & JOYSTICK_RIGHT) {            //P1_24    //Mutex
		for(;;){
			count3=r+count3+count3;
			joystick_position = Joystick_GetState();
			if (joystick_position & JOYSTICK_LEFT || joystick_position & JOYSTICK_DOWN ) {		
				trans = osThreadCreate(osThread(transition),NULL); 
			}		
		}
	}	
		
	if (joystick_position & JOYSTICK_DOWN) {         //P1_25    //Semaphore
		for(;;){
			count3=r+count3+count3;
			joystick_position = Joystick_GetState();
			if (joystick_position & JOYSTICK_LEFT || joystick_position & JOYSTICK_RIGHT) {		
				trans = osThreadCreate(osThread(transition),NULL); 
			}		
		}
	}			
		
	if (joystick_position & JOYSTICK_LEFT) {					//P1_26   // Resemble Semaphore
		for(;;){
			count3=r+count3+count3;
			joystick_position = Joystick_GetState();
			if (joystick_position & JOYSTICK_RIGHT || joystick_position & JOYSTICK_DOWN ) {		
				trans = osThreadCreate(osThread(transition),NULL); 
			}		
		}
	}
	for(;;){
		count3=r+count3+count3;
		joystick_position = Joystick_GetState();
		if(joystick_position & JOYSTICK_DOWN || joystick_position & JOYSTICK_RIGHT || joystick_position & JOYSTICK_LEFT){
			trans = osThreadCreate(osThread(transition),NULL); 	
		}
	}	
}	

void taskC (void const *argument) {
	osStatus s;	


	if (joystick_position & JOYSTICK_RIGHT) {            //P24 Mutex
		for(;;){
			s = osMutexWait(mut,osWaitForever);
			if (s == osOK){	
				osDelay(200);
				LED_Off(0);
				delay();
			}	
			osMutexRelease(mut);
			joystick_position = Joystick_GetState();
			if (joystick_position & JOYSTICK_LEFT || joystick_position & JOYSTICK_DOWN ) {		
				trans = osThreadCreate(osThread(transition),NULL); 
			}		
		}
	}	
		
	if (joystick_position & JOYSTICK_DOWN) {         //P25 Semaphore
		osSemaphoreWait(sem,osWaitForever);
		osDelay(200);
		for(;;){
			LED_Off(0);
			delay();
			osThreadSetPriority(P3,osPriorityBelowNormal);
			osSemaphoreRelease(sem);
		
			joystick_position = Joystick_GetState();
			if (joystick_position & JOYSTICK_LEFT || joystick_position & JOYSTICK_RIGHT ) {		
				trans = osThreadCreate(osThread(transition),NULL); 
			}	
		}	
	}			
		
	if (joystick_position & JOYSTICK_LEFT) {					//P26 Resemble Semaphore
		variable = 1;
		osDelay(200);
		while(1){
			if(variable == 1){
				delay();
				count2 = 0;
				variable = 0;
				osThreadSetPriority(P3, osPriorityBelowNormal);
			}
			joystick_position = Joystick_GetState();
			if (joystick_position & JOYSTICK_DOWN || joystick_position & JOYSTICK_RIGHT ) {		
				trans = osThreadCreate(osThread(transition),NULL); 
			}
		}
	}
	for(;;){
		delay();
		osSignalWait(0x01,osWaitForever); 	
		LED_Off(0);
		osSignalSet(P1,0x02);	
		joystick_position = Joystick_GetState();
		if(joystick_position & JOYSTICK_DOWN || joystick_position & JOYSTICK_RIGHT || joystick_position & JOYSTICK_LEFT){
			trans = osThreadCreate(osThread(transition),NULL); 	
		}
	}		
}

void transition (void const *argument) {
	step();
	osThreadTerminate(trans);
}

int main(void)
{    
	osKernelInitialize (); 
	LED_Initialize();
	t_main = osThreadGetId ();                         
	osThreadSetPriority(t_main,osPriorityHigh);             
	Joystick_Initialize();                        
	
	sem = osSemaphoreCreate(osSemaphore(sem),1);
	mut = osMutexCreate(osMutex(mut));
	
	printf("Choose P1_24 : Mutex , P1_25: Semaphore, P1_26: Resemble Semaphore\n");

	joystick_position = Joystick_GetState();  
	init_thread();
	 
	osThreadTerminate(t_main);                             
	osKernelStart ();	
	for (;;) {}
}







